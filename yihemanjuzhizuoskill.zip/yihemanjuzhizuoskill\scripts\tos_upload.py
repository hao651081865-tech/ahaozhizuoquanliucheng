"""
TOS file upload tool.

Usage:
    python scripts/tos_upload.py <file_path> [--bucket <bucket_name>] [--object-key <key>] [--region <region>]
"""

import argparse
import json
import logging
import os
import sys
from datetime import datetime
from typing import Optional

import tos
from tos import HttpMethodType

logger = logging.getLogger(__name__)

DEFAULT_BUCKET = "agentkit-platform-2107625663"
DEFAULT_REGION = "cn-beijing"


def _get_env(name: str, default: Optional[str] = None) -> Optional[str]:
    value = os.getenv(name)
    if value:
        return value
    if os.name == "nt":
        try:
            import winreg

            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ
            ) as key:
                value, _ = winreg.QueryValueEx(key, name)
                return value or default
        except OSError:
            return default
    return default


def upload_file_to_tos(
    file_path: str,
    bucket_name: Optional[str] = None,
    object_key: Optional[str] = None,
    region: Optional[str] = None,
    expires: int = 604800,
) -> Optional[str]:
    """Upload a local file to TOS and return a signed URL."""
    if bucket_name is None:
        bucket_name = _get_env("DATABASE_TOS_BUCKET", DEFAULT_BUCKET)
    if region is None:
        region = _get_env("DATABASE_TOS_REGION", DEFAULT_REGION)

    if not os.path.exists(file_path):
        logger.error("File does not exist: %s", file_path)
        return None
    if not os.path.isfile(file_path):
        logger.error("Path is not a file: %s", file_path)
        return None

    try:
        from get_aksk import get_aksk

        cred = get_aksk()
        access_key = cred["access_key"]
        secret_key = cred["secret_key"]
        session_token = cred["session_token"]
    except RuntimeError as exc:
        logger.error("Failed to get AK/SK: %s", exc)
        return None

    if not object_key:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.basename(file_path)
        object_key = f"upload/{filename}_{timestamp}"

    client = None
    try:
        endpoint = f"tos-{region}.volces.com"
        client = tos.TosClientV2(
            ak=access_key,
            sk=secret_key,
            security_token=session_token,
            endpoint=endpoint,
            region=region,
        )

        try:
            client.head_bucket(bucket_name)
        except tos.exceptions.TosServerError as exc:
            if exc.status_code == 404:
                logger.error("Bucket does not exist: %s", bucket_name)
                return None
            raise

        client.put_object_from_file(
            bucket=bucket_name,
            key=object_key,
            file_path=file_path,
        )

        signed_url_output = client.pre_signed_url(
            http_method=HttpMethodType.Http_Method_Get,
            bucket=bucket_name,
            key=object_key,
            expires=expires,
        )
        return signed_url_output.signed_url

    except tos.exceptions.TosClientError as exc:
        logger.error("TOS client error: %s", exc)
        return None
    except tos.exceptions.TosServerError as exc:
        logger.error(
            "TOS server error: status=%s, code=%s, message=%s",
            exc.status_code,
            exc.code,
            exc.message,
        )
        return None
    except Exception as exc:
        logger.error("Upload failed: %s", exc)
        return None
    finally:
        if client:
            client.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Upload a file to TOS")
    parser.add_argument("file_path", help="Local file path")
    parser.add_argument("--bucket", default=None, help="TOS bucket name")
    parser.add_argument("--object-key", default=None, help="TOS object key")
    parser.add_argument("--region", default=None, help="TOS region")
    parser.add_argument("--expires", type=int, default=604800, help="Signed URL TTL seconds")
    args = parser.parse_args()

    url = upload_file_to_tos(
        file_path=args.file_path,
        bucket_name=args.bucket,
        object_key=args.object_key,
        region=args.region,
        expires=args.expires,
    )

    if url:
        print(json.dumps({"signed_url": url}, ensure_ascii=False))
    else:
        print(json.dumps({"error": "upload failed"}, ensure_ascii=False))
        sys.exit(1)
