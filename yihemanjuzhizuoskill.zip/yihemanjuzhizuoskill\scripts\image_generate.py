import argparse
import json
import os
import time

try:
    from .lk888_image_client import (
        DEFAULT_ASSET_DIR,
        DEFAULT_POLL_INTERVAL,
        DEFAULT_TIMEOUT,
        Lk888ImageClient,
    )
except ImportError:
    from lk888_image_client import (
        DEFAULT_ASSET_DIR,
        DEFAULT_POLL_INTERVAL,
        DEFAULT_TIMEOUT,
        Lk888ImageClient,
    )


def image_generate(prompt: str, output_dir: str | None = None, images: list[str] | None = None) -> list[str]:
    if output_dir is None:
        output_dir = os.getenv("IMAGE_DOWNLOAD_DIR") or os.getenv("CODEX_ASSET_DIR") or DEFAULT_ASSET_DIR

    filename = f"generated_image_{int(time.time())}_0.png"
    client = Lk888ImageClient()
    return client.generate_image(
        prompt=prompt,
        output_dir=output_dir,
        filename=filename,
        image_urls=images,
        poll_interval=int(os.getenv("LK888_POLL_INTERVAL", DEFAULT_POLL_INTERVAL)),
        timeout=int(os.getenv("LK888_TIMEOUT", DEFAULT_TIMEOUT)),
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate an image using lk888.ai GPT Image 2")
    parser.add_argument("prompt", help="Text prompt for image generation")
    parser.add_argument("--output-dir", default=None, help="Directory to save generated images")
    parser.add_argument("--images", nargs="*", default=None, help="Optional reference image URLs")
    args = parser.parse_args()

    paths = image_generate(args.prompt, args.output_dir, args.images)
    print(json.dumps({"saved_files": paths}, ensure_ascii=False, indent=2))
