---
name: yihemanjuzhizuoskill
description: 一禾漫剧制作技能。Use when the user wants Codex to produce AI漫剧、漫画短剧、微短剧、短视频漫剧 or “从故事创意到成片”的完整流程，包括剧本、角色/场景/道具参考资产、导演级分镜提示词、全能参考视频生成、视频合成、质检、重试和本地交付。Triggers include “做漫剧/生成漫剧/AI漫剧/漫画短剧/一禾漫剧/分镜视频/全能参考出视频/把故事做成视频”。
---

# 一禾漫剧制作技能

Use this skill as the production director for AI漫剧 projects. The standard pipeline is:

`故事创意 -> 剧本 -> 人物/场景/道具参考资产 -> 图片资产预览确认 -> 分镜视频提示词 -> 全能参考出视频 -> 合成成片 -> 质检交付`

## 不可违背规则

- 不生成故事版分镜图、不生成分镜首帧图、不准备 `frames.json`，也不得调用任何 first-frame 视频流程，除非用户明确覆盖本 skill。
- 视频生成只使用“全能参考出视频”：把人物资产、场景资产、道具资产和分镜提示词一起提交给当前已批准的视频接口。
- 生图、生视频都必须直接调用已批准 API/模型，通过脚本或适配器执行；不得使用网页登录、浏览器 UI 操作或手动网页上传，除非用户明确要求网页/手动流程。
- 视频 API 会经常变化。不得在 skill 中写死临时 API URL，不得失败后擅自切换 API/provider。当前 API、鉴权、上传、查询和下载规则以用户明确批准的配置/适配器为准；配置不完整或接口变更时，停下询问用户。
- 不得在未获用户明确允许的情况下修改本 skill 或脚本。需要改规则、改接口、改模型或改脚本时，先说明改动并等待授权。
- 用户未说明画风时，先询问；若用户在同一项目已指定“真人写实/写实风格”，后续沿用真人写实，不得擅自改成 3D、动漫、插画或卡通。
- 图片资产和生成视频都不得出现明显明星脸、公众人物相似或可识别真人相似。发现此类问题，判定为质检失败，报告风险但不点名真实人物，并询问用户后再决定是否重生或调整提示词。
- 如果出现真实人物隐私拦截、内容审核拦截、画风不符、明星脸或模型不可用，不得擅自换风格、换模型、换 provider 或绕过；必须停下询问用户。
- 每一部剧进入生视频阶段前都要确认视频模型。若用户已在本剧明确指定模型，则使用该模型；若未指定，必须询问。当前用户已明确要求使用 `sd-2-motion-plus-720` 时，不得自动切回 fast/pro。
- 人物、场景、道具图片资产生成并质检后，必须展示全部资产预览，并明确询问用户是否确认继续生成视频。未得到用户确认前，不得提交任何视频任务。
- 每部剧的所有本地产物统一保存到 `CODEX_ASSET_DIR/{剧名}/`；如果未设置，使用 `D:\codex资产\{剧名}\`。
- 不再默认创建 `E:\codex漫剧流程`、`E:\codex漫剧成片`、`E:\codex漫剧资产` 等分散目录；除非用户明确指定，漫剧产物不得放到 E 盘或 C 盘。
- 图片资产和分镜视频只保留一份权威文件：人物图只放 `{剧名}/人物资产/`，场景图只放 `{剧名}/场景资产/`，道具图只放 `{剧名}/道具资产/`，分镜视频只放 `{剧名}/视频/{集数}/`。过程文件只放 `{剧名}/prompts/` 和 `{剧名}` 根目录文档，不得再创建或复制一份 `characters/`、`assets/`、`videos/`、`final/` 产物目录。
- 最终合成片直接保存到 `D:\codex资产\{剧名}\{剧名}_final.mp4` 或当前 `CODEX_ASSET_DIR/{剧名}/{剧名}_final.mp4`。
- 每个关键阶段都要在对话中展示核心产物：剧本摘要、图片资产预览、分镜文本、生成视频片段、最终视频和质检结果。
- 展示视频时使用 `<video src="{absolute_local_path_or_url}" width="640" controls>描述</video>`。

## 参考文件路由

按阶段只读取需要的参考文件：

- 剧本和剧情大纲：`references/screenplay-generator.md`
- 人物参考资产：`references/character-designer.md`
- 场景/道具参考资产：`references/scene-designer.md`
- 导演级分镜视频提示词：`references/storyboard-director.md`
- 视频合成和最终交付：`references/video-synthesizer.md`
- 完整示例：`examples/examples.md`
- 旧版全量说明仅作兼容检索：`references/original-full-skill.md`。若旧版内容与本文件冲突，一律以本文件为准。

## 标准生产流程

1. 只在必要信息缺失时询问：故事、集数/时长、画风、语言、是否需要公网链接、视频模型。
2. 初始化项目目录，建立唯一剧名总目录 `D:\codex资产\{剧名}\`。
   - 初始化返回的 `task_folder`、`assets_dir`、`final_dir` 必须都指向同一个剧名总目录；`characters_dir`、`scenes_dir`、`props_dir`、`videos_dir` 是这个剧名总目录内的最小分类目录。
3. 做内容安全预审，把真实血腥、极端暴力、政治敏感等高风险表达改成更安全的影视化表达；不能擅自改变剧情核心。
4. 生成 `requirements.md`、`plot.md`、`script.md`。
5. 生成人物参考资产并质检：真人写实时必须是真人实拍影视感，不是 3D；不得明星脸，不得多人混入，不得三视图身份不一致，不得缺肢多肢，不得带可分离道具。
6. 生成场景和道具参考资产并质检：场景必须是可复用环境参考，不是分镜首帧；道具必须一物一图；任何人脸都不得明星脸。
7. 展示全部人物、场景、道具图片资产预览，询问用户是否确认继续生成视频。
8. 用户确认后，按当前确认的视频模型生成中文导演级分镜提示词，并使用当前已批准 API/适配器直接提交视频任务。
9. 视频逐段质检：检查人物一致性、明星脸、重复人物、缺肢多肢、脸和服装漂移、道具错用、场景不连续、对白不符、字幕水印和卡顿。涉及明星脸/隐私/画风问题必须问用户后再重生。
10. 所有分段视频通过质检后，使用 `scripts/video_merge.py` 合成最终视频；进入合成阶段时检查 `ffmpeg`。
11. 保存最终成片到剧名总目录根部，运行完整性检查和质量评分，并展示最终视频。

## 脚本调用要点

从 skill 目录运行脚本，除非脚本说明需要其他工作目录。

```bash
python scripts/app_config.py
python scripts/task_manager.py init "<剧名>"
python scripts/batch_image_generate.py --prompts-file prompts.json --output-dir "<资产目录>" --prefix character_ --max-workers 3 --max-retries 3
python scripts/batch_video.py validate --prompts-file prompts.json --durations-file durations.json --reference-assets-file reference_assets_manifest.json
python scripts/batch_video.py generate --prompts-file prompts.json --durations-file durations.json --reference-assets-file reference_assets_manifest.json --output-dir "<视频目录>"
python scripts/video_merge.py --input-dir "<视频目录>" --output "<D:\codex资产\剧名\剧名_final.mp4>" --scene-count <N>
python scripts/verify_task.py "<任务目录>"
python scripts/video_scorer.py "<任务目录>"
```

## 质量门槛

- 图片资产质检通过并获得用户确认前，不得进入视频生成。
- 任何阶段不得出现明显明星脸、公众人物相似或可识别真人相似。
- 失败重试只适用于网络、排队、并发限制、HTTP 429 等临时问题；余额不足、模型无权限、账号错误、内容/隐私/明星脸风险必须停止并报告。
- 失败视频只处理失败段，已通过段不动；但涉及明星脸/隐私/画风时必须先问用户。
- 任务未生成最终片时，必须清楚说明当前已完成到哪一步、缺什么、阻塞原因是什么。
